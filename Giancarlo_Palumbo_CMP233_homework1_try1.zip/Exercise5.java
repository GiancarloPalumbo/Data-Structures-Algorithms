/* Giancarlo Palumbo
 Professor Sawh
 Homework #1
 10/4/2023 */

 // Write a recursive method that writes a given array backward. Consider the last element of the array first


public class Exercise5
{

    public static void reverseArray(int[] a, int startIndex, int endIndex)
    {
        // If the startIndex surpasses the endIndex, stop the recursion.
        if (startIndex >= endIndex)
        {
            return;
        }

        // Swap the elements at startIndex and endIndex.
        int temp = a[startIndex];
        a[startIndex] = a[endIndex];
        a[endIndex] = temp;

        // Recursively reverse the rest of the array.
        reverseArray(a, startIndex + 1, endIndex - 1);
    }

    public static void main(String[] args)
    {
        int[] a = {1, 2, 3, 4, 5};
        int startIndex = 0;
        int endIndex = a.length - 1;

        System.out.println("Original array:");
        for (int value : a)
        {
            System.out.print(value + " ");
        }

        // Call the reverseArray method to reverse the array.
        reverseArray(a, startIndex, endIndex);

        System.out.println("\nReversed array:");
        for (int value : a)
        {
            System.out.print(value + " ");
        }
    }
}
