/* Giancarlo Palumbo
 Professor Sawh
 Homework #1
 10/4/2023 */

/*	Write a method that asks the user for integer input that is between 1 and 10, inclusive.
If the input is out of range, the method should recursively ask the user to enter a new input value.
*/

import java.util.Scanner;

public class Exercise3
{

    public static int getUserInput()
    {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Please enter an integer between 1 and 10. It can include 1 or 10.");
        int userInput = scanner.nextInt();

        if (userInput < 1 || userInput > 10)
        {
            System.out.println("Invalid input. Please enter a number between 1 and 10.");
            // Recursively call the method to ask for input again.
            return getUserInput();
    	}

        return userInput;
    }

    public static void main(String[] args)
    {
        int userInput = getUserInput();
        System.out.println("You entered: " + userInput);
    }
}// end of class
