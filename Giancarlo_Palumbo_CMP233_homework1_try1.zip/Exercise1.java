/* Giancarlo Palumbo
 Professor Sawh
 Homework #1
 10/4/2023 */

/* Consider the method "displayRowofCharacters" that displays any given character the specified
number of times on one line. For example, the call
	displayRowofCharacters('*', 5);

produces the line
	*****
	Implement this method using recursion

*/

public class Exercise1
{

    public static void displayRowOfCharacters(char c, int t) {
        // Base case: If t is less than or equal to 0, return.
        if (t <= 0) {
            return;
        }

        // Print the character without a newline.
        System.out.print(c);

        // Recursively call the method with t-1.
        displayRowOfCharacters(c, t - 1);
        System.out.println();
    }

    public static void main(String[] args) {
        char c = '*'; // Change this to the character you want to display.
        int t = 5; // Change this to the number of times you want to display the character.

        displayRowOfCharacters(c, t);
    }
}

