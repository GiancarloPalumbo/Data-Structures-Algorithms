/* Giancarlo Palumbo
 Professor Sawh
 Homework #1
 10/4/2023 */

 // Repeat exercise 5 and 6, but write a string backward instead of an array

public class Exercise7
{

    // Reverse the string considering the last character first
    public static String reverseStringLastFirst(String input)
    {
        if (input == null || input.length() <= 1)
        {
            return input;
        }
        char lastChar = input.charAt(input.length() - 1);
        String remaining = input.substring(0, input.length() - 1);
        return lastChar + reverseStringLastFirst(remaining);
    }

    // Reverse the string considering the first character first
    public static String reverseStringFirstFirst(String input)
    {
        if (input == null || input.length() <= 1)
        {
            return input;
        }
        char firstChar = input.charAt(0);
        String remaining = input.substring(1);
        return reverseStringFirstFirst(remaining) + firstChar;
    }

    public static void main(String[] args)
    {
        String input = "Hello, World";

        // Reverse the string considering the last character first
        String reversedLastFirst = reverseStringLastFirst(input);
        System.out.println("Original string (Last First): " + input);
        System.out.println("Reversed string (Last First): " + reversedLastFirst);

        // Reverse the string considering the first character first
        String reversedFirstFirst = reverseStringFirstFirst(input);
        System.out.println("\nOriginal string (First First): " + input);
        System.out.println("Reversed string (First First): " + reversedFirstFirst);
    }
}
