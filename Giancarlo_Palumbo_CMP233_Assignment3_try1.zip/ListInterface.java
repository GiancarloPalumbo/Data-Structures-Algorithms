public interface ListInterface
{
    public void add(int element) throws ListException;
    public void display();
}