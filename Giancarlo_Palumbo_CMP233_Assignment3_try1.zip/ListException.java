class ListException extends Exception
{
    public ListException(String message)
    {
        System.out.println(message);
    }
}